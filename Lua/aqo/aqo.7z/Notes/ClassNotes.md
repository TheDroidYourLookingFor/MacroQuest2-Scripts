# Notes

Each class has an associated `<class_short_name>.lua` file which defines all of the class specific information including spells, AAs, discs, skills, spell rotations, buffs, etc.

